"""Composite-eval manifest builder.

Scans known dataset roots on disk and emits a TOML manifest suitable
for ``tabvision-composite-eval``. Designed to be deterministic so
re-runs on the same data produce byte-identical output: clips are
emitted in sorted-id order, and per-tier caps + total limits are
applied after that sort.

Currently supports:

- **GuitarSet** (CC-BY-4.0) — clean acoustic single-line + strummed
  tiers. Default split = player 05 → validation, others → train.
- **Guitar-TECHS** (CC-BY-4.0) — stubbed; Phase 0 returns ``[]`` until
  the dataset is acquired locally and the on-disk layout is verified.

EGDB is intentionally not yet wired up (license-pending per the
2026-05-13 design plan).
"""

from __future__ import annotations

import argparse
import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from tabvision.eval.manifest import (
    SYNTHETIC_SOURCE_PREFIXES,
    ManifestValidation,
    validate_manifest,
)

GUITARSET_VALIDATION_PLAYER = "05"


@dataclass(frozen=True)
class ClipEntry:
    """Minimal clip-row representation, one per manifest ``[[clips]]``."""

    id: str
    tier: str
    source: str
    split: str
    media_path: str
    annotation_path: str
    annotation_format: str


def _guitarset_tier(track_id: str) -> str | None:
    """Map a GuitarSet track id suffix to a SPEC §1.4 tier name.

    Returns ``None`` for unrecognised suffixes (track is skipped).
    """
    if track_id.endswith("_comp"):
        return "clean_acoustic_strummed"
    if track_id.endswith("_solo"):
        return "clean_acoustic_single_line"
    return None


def _guitarset_split(track_id: str, validation_player: str) -> str:
    """``validation`` for the held-out player, ``train`` otherwise."""
    if track_id.split("_", 1)[0] == validation_player:
        return "validation"
    return "train"


def scan_guitarset(
    root: Path,
    *,
    validation_player: str = GUITARSET_VALIDATION_PLAYER,
) -> list[ClipEntry]:
    """Scan a GuitarSet directory tree and return discovered clips.

    Expected layout::

        <root>/annotation/<track>.jams
        <root>/audio_mono-mic/<track>_mic.wav

    Tracks missing either file are skipped. Tracks whose suffix is
    neither ``_comp`` nor ``_solo`` are skipped.
    """
    annotation_dir = root / "annotation"
    audio_dir = root / "audio_mono-mic"
    if not annotation_dir.is_dir() or not audio_dir.is_dir():
        return []

    entries: list[ClipEntry] = []
    for jams_path in sorted(annotation_dir.glob("*.jams")):
        track_id = jams_path.stem
        media_path = audio_dir / f"{track_id}_mic.wav"
        if not media_path.is_file():
            continue
        tier = _guitarset_tier(track_id)
        if tier is None:
            continue
        entries.append(
            ClipEntry(
                id=f"guitarset/{track_id}",
                tier=tier,
                source="GuitarSet",
                split=_guitarset_split(track_id, validation_player),
                media_path=str(media_path.resolve()),
                annotation_path=str(jams_path.resolve()),
                annotation_format="guitarset_jams",
            )
        )
    return entries


def scan_utaustin(root: Path) -> list[ClipEntry]:
    """Scan the Kaggle/UT-Austin tablature dataset into eval clip entries.

    Expected layout::

        <root>/tablature_audio/<clip>.wav
        <root>/tablature_labels/<clip>.npy
        <root>/timestamps.csv

    All entries are validation entries because this corpus is NC eval evidence,
    not training material for shipped weights.
    """
    label_dir = root / "tablature_labels"
    audio_dir = root / "tablature_audio"
    if not label_dir.is_dir() or not audio_dir.is_dir() or not (root / "timestamps.csv").is_file():
        return []

    entries: list[ClipEntry] = []
    for label_path in sorted(label_dir.glob("*.npy"), key=lambda p: int(p.stem)):
        audio_path = audio_dir / f"{label_path.stem}.wav"
        if not audio_path.is_file():
            continue
        entries.append(
            ClipEntry(
                id=f"utaustin/{label_path.stem}",
                tier="clean_acoustic_single_line",
                source="KaggleUTAustin",
                split="validation",
                media_path=str(audio_path.resolve()),
                annotation_path=str(label_path.resolve()),
                annotation_format="utaustin_tablature_npy",
            )
        )
    return entries


# Standard tuning, low E .. high E. GAPS clips in scordatura (e.g. drop-D) are
# not playable by the standard-tuning pipeline and are filtered out of eval
# splits (logged, not silently capped) — their gold (string, fret) is
# unreachable from a standard fretboard, so scoring would be meaningless.
GAPS_STANDARD_TUNING: tuple[int, ...] = (40, 45, 50, 55, 59, 64)


def _gaps_splits_from_csv(csv_path: Path) -> dict[str, str]:
    """Map GAPS clip stem -> official split from the metadata CSV.

    The CSV ``id`` column carries the ``NNN_<code>`` stem; ``split`` is one of
    ``train`` / ``test`` / empty (unlabeled). Stems with an empty split are
    omitted (they are not part of the official train/test partition).
    """
    import csv as _csv  # noqa: PLC0415

    out: dict[str, str] = {}
    with open(csv_path, newline="", encoding="utf-8") as fh:
        for row in _csv.DictReader(fh):
            stem = (row.get("id") or "").strip()
            split = (row.get("split") or "").strip()
            if stem and split in {"train", "test"}:
                out[stem] = split
    return out


def _gaps_is_standard_tuning(xml_path: Path) -> bool:
    """True iff the clip's tab staff uses standard tuning (no scordatura)."""
    from tabvision.eval.parsers.gaps_musicxml_tab import read_staff_tuning  # noqa: PLC0415

    tuning = read_staff_tuning(xml_path)
    if len(tuning) != 6:
        return False
    # read_staff_tuning keys are MusicXML string numbers 1..6 (1 = high E);
    # GAPS_STANDARD_TUNING is indexed low E (idx 0) .. high E (idx 5), so
    # string number s maps to index 6 - s.
    return all(tuning.get(s) == GAPS_STANDARD_TUNING[6 - s] for s in range(1, 7))


def scan_gaps(
    root: Path,
    *,
    standard_tuning_only: bool = True,
) -> list[ClipEntry]:
    """Scan a GAPS dataset root into ``clean_acoustic_single_line`` clip entries.

    Expected layout (HF ``xavriley/GAPS`` mirror)::

        <root>/musicxml/<stem>.xml         (TAB part with <string>/<fret>)
        <root>/midi/<stem>.mid             (aligned performance MIDI)
        <root>/syncpoints/<stem>.json      (per-measure downbeat seconds)
        <root>/audio/<stem>.wav            (performance audio)
        <root>/gaps_metadata_with_splits.csv

    A clip is included only if all four media/annotation files exist AND the CSV
    assigns it a ``train``/``test`` split. With ``standard_tuning_only`` (the
    default), scordatura clips are dropped — the gold ``(string, fret)`` is
    unreachable by the standard-tuning pipeline. Classical solo guitar is
    single-line. GAPS is NC offline-eval-only: paths point at the local mirror;
    media is never committed/redistributed.
    """
    musicxml_dir = root / "musicxml"
    csv_path = root / "gaps_metadata_with_splits.csv"
    if not musicxml_dir.is_dir() or not csv_path.is_file():
        return []

    splits = _gaps_splits_from_csv(csv_path)
    entries: list[ClipEntry] = []
    for xml_path in sorted(musicxml_dir.glob("*.xml")):
        stem = xml_path.stem
        split = splits.get(stem)
        if split is None:
            continue
        midi_path = root / "midi" / f"{stem}.mid"
        sync_path = root / "syncpoints" / f"{stem}.json"
        audio_path = root / "audio" / f"{stem}.wav"
        if not (midi_path.is_file() and sync_path.is_file() and audio_path.is_file()):
            continue
        if standard_tuning_only and not _gaps_is_standard_tuning(xml_path):
            continue
        entries.append(
            ClipEntry(
                id=f"gaps/{stem}",
                tier="clean_acoustic_single_line",
                source="GAPS",
                split=split,
                media_path=str(audio_path.resolve()),
                annotation_path=str(xml_path.resolve()),
                annotation_format="gaps_musicxml_tab",
            )
        )
    return entries


GUITAR_TECHS_VALIDATION_PLAYER = "03"

# Stretch-goal articulations (SPEC §1.4 → v1.1). Skipped so the clean_electric
# tier scores clean transcription, not expression. Matched case-insensitively
# anywhere in a clip's path.
_GT_SKIP_KEYWORDS: tuple[str, ...] = (
    "bend",
    "vibrato",
    "pinch",
    "harmonic",
    "palm",
    "slide",
    "hammer",
    "pull",
    "trill",
)
_GT_AUDIO_EXTS: tuple[str, ...] = (".wav", ".flac", ".aiff", ".aif")
# Audio-capture preference for the clean_electric tier: direct input (clean DI)
# before mic'd amp. Ranked by first hit in the path (lower index = preferred).
_GT_AUDIO_PREF: tuple[str, ...] = (
    "directinput",
    "direct",
    "di",
    "clean",
    "micamp",
    "mic",
)
# Performer id from a path component: 'P1_chords', 'player01', 'guitarist3', 'p02'.
# Anchored at the component start with a trailing separator/end so substrings like
# 'tmp12' don't false-match. Unmatched -> split='train' (safe; fine for #2 where
# all of Guitar-TECHS is held out w.r.t. the GuitarSet-trained prior anyway).
_GT_PLAYER_RE = re.compile(r"^(?:player|guitarist|p)[_\-]?(\d{1,2})(?:[_\-]|$)", re.IGNORECASE)


def _guitar_techs_player(path_parts: tuple[str, ...]) -> str | None:
    """Best-effort performer id from a path *component* (e.g. 'P1_chords' -> '01')."""
    for part in path_parts:
        match = _GT_PLAYER_RE.match(part)
        if match:
            return match.group(1).zfill(2)
    return None


def _gt_content(stem: str) -> str:
    """Content id shared by a clip's MIDI and audio files.

    Guitar-TECHS names files ``<capture>_<content>`` -- MIDI ``midi_Drop3_7``
    and audio ``directinput_Drop3_7`` share ``Drop3_7``. Returns everything
    after the first underscore (or the whole stem if there is none).
    """
    return stem.split("_", 1)[1] if "_" in stem else stem


def _gt_group_dir(path: Path, root: Path) -> Path:
    """The performer/category group dir (e.g. ``P1_chords``) -- first part under root."""
    rel = path.relative_to(root)
    return root / rel.parts[0] if rel.parts else path.parent


def _gt_audio_rank(path: Path) -> int:
    """Lower = preferred capture (direct input before mic'd amp)."""
    low = str(path).lower()
    for i, hint in enumerate(_GT_AUDIO_PREF):
        if hint in low:
            return i
    return len(_GT_AUDIO_PREF)


def scan_guitar_techs(
    root: Path,
    *,
    validation_player: str = GUITAR_TECHS_VALIDATION_PLAYER,
) -> list[ClipEntry]:
    """Scan a Guitar-TECHS tree into ``clean_electric`` clip entries.

    Layout (verified 2026-06-02 against Zenodo record 14963133)::

        <root>/<Pn_category>/midi/midi_<content>.mid
        <root>/<Pn_category>/audio/directinput/directinput_<content>.wav
        <root>/<Pn_category>/audio/micamp/micamp_<content>.wav

    All electric -> the single ``clean_electric`` tier (SPEC 1.4 has no electric
    single-line/strummed split). MIDI<->audio are paired by the shared
    ``<content>`` token (the part after the first underscore), scoped to the same
    Pn_category group -- NOT by a common prefix. Direct-input audio is preferred
    over mic'd amp. Stretch-goal technique clips are skipped; ``__MACOSX`` zip
    cruft is ignored. Split by performer (``P3`` -> validation by default).
    Returns ``[]`` gracefully if no pairable MIDI is found.
    """
    if not root.is_dir():
        return []

    audio_by_group: dict[Path, list[Path]] = {}
    for ext in _GT_AUDIO_EXTS:
        for path in root.rglob(f"*{ext}"):
            if "__macosx" in str(path).lower():
                continue
            audio_by_group.setdefault(_gt_group_dir(path, root), []).append(path)

    entries: list[ClipEntry] = []
    seen: set[str] = set()
    for midi_path in sorted(root.rglob("*.mid")) + sorted(root.rglob("*.midi")):
        path_low = str(midi_path).lower()
        if "__macosx" in path_low or any(kw in path_low for kw in _GT_SKIP_KEYWORDS):
            continue
        content = _gt_content(midi_path.stem)
        candidates = [
            p
            for p in audio_by_group.get(_gt_group_dir(midi_path, root), [])
            if _gt_content(p.stem) == content
        ]
        if not candidates:
            continue
        audio_path = sorted(candidates, key=lambda p: (_gt_audio_rank(p), str(p)))[0]
        rel = midi_path.relative_to(root)
        clip_id = f"guitar-techs/{rel.with_suffix('').as_posix()}"
        if clip_id in seen:
            continue
        seen.add(clip_id)
        player = _guitar_techs_player(midi_path.parts)
        split = "validation" if player == validation_player else "train"
        entries.append(
            ClipEntry(
                id=clip_id,
                tier="clean_electric",
                source="GuitarTECHS",
                split=split,
                media_path=str(audio_path.resolve()),
                annotation_path=str(midi_path.resolve()),
                annotation_format="guitar_techs_midi",
            )
        )
    return entries


def apply_limits(
    entries: Iterable[ClipEntry],
    *,
    max_clips_per_tier: int | None = None,
    total_limit: int | None = None,
) -> list[ClipEntry]:
    """Apply per-tier and total limits deterministically.

    Entries are first sorted by ``id`` (so the same data produces the
    same output regardless of input scan order), then per-tier capped,
    then total-limited.
    """
    sorted_entries = sorted(entries, key=lambda entry: entry.id)

    if max_clips_per_tier is not None and max_clips_per_tier >= 0:
        by_tier: dict[str, int] = {}
        capped: list[ClipEntry] = []
        for entry in sorted_entries:
            count = by_tier.get(entry.tier, 0)
            if count >= max_clips_per_tier:
                continue
            capped.append(entry)
            by_tier[entry.tier] = count + 1
        sorted_entries = capped

    if total_limit is not None and 0 <= total_limit < len(sorted_entries):
        sorted_entries = sorted_entries[:total_limit]

    return sorted_entries


def _toml_escape(value: str) -> str:
    """Escape a TOML basic-string value (backslashes + double quotes)."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _relativize_to_data_root(path_str: str, data_root: Path | None) -> str:
    """Rewrite ``path_str`` as ``$TABVISION_DATA_ROOT/<rest>`` when it lives
    under ``data_root``. Returns the original string when ``data_root`` is
    ``None`` or the path isn't under it.

    ``data_root`` must already be expanded + resolved by the caller
    (:func:`render_toml` does this once). Matching uses :mod:`pathlib`
    rather than a ``startswith(abs_root + "/")`` string prefix: the prefix
    form hard-codes a forward slash, so on Windows -- where absolute paths
    are backslash-separated -- it never matched and silently leaked
    ``C:\\...`` paths into checked-in manifests. ``Path.relative_to`` is
    separator-correct on the native platform, and ``as_posix`` emits the
    forward-slash ``$TABVISION_DATA_ROOT/<rest>`` token regardless of host.

    The composite-eval CLI expands ``$TABVISION_DATA_ROOT`` at eval time
    via the env var or its ``--media-root`` / ``--annotation-root`` args
    (see :func:`tabvision.eval.composite._resolve_path`), so this keeps
    checked-in manifests portable across developer machines.
    """
    if data_root is None:
        return path_str
    try:
        rel = Path(path_str).relative_to(data_root)
    except ValueError:
        return path_str
    posix = rel.as_posix()
    return "$TABVISION_DATA_ROOT" if posix == "." else f"$TABVISION_DATA_ROOT/{posix}"


def render_toml(
    entries: Iterable[ClipEntry],
    *,
    header_comment: str = "",
    data_root: Path | None = None,
) -> str:
    """Render entries as a TOML composite manifest.

    Output is sorted by clip id for byte-stable re-generation. When
    ``data_root`` is provided, ``media_path`` and ``annotation_path``
    values that fall under that root are rewritten as
    ``$TABVISION_DATA_ROOT/<rest>`` — the composite-eval CLI expands
    that token at eval time. Use this for checked-in manifests.
    """
    sorted_entries = sorted(entries, key=lambda entry: entry.id)
    resolved_root = data_root.expanduser().resolve() if data_root is not None else None
    lines: list[str] = []
    if header_comment:
        for raw_line in header_comment.splitlines():
            lines.append(f"# {raw_line}" if raw_line else "#")
        lines.append("")
    fields = (
        "id",
        "tier",
        "source",
        "split",
        "media_path",
        "annotation_path",
        "annotation_format",
    )
    for entry in sorted_entries:
        lines.append("[[clips]]")
        for field in fields:
            raw = getattr(entry, field)
            if field in ("media_path", "annotation_path"):
                raw = _relativize_to_data_root(raw, resolved_root)
            value = _toml_escape(raw)
            lines.append(f'{field} = "{value}"')
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def summarise_coverage(entries: Iterable[ClipEntry]) -> str:
    """Human-readable coverage summary."""
    entries_list = list(entries)
    by_tier: dict[str, dict[str, int]] = {}
    by_split: dict[str, int] = {}
    for entry in entries_list:
        by_tier.setdefault(entry.tier, {}).setdefault(entry.source, 0)
        by_tier[entry.tier][entry.source] += 1
        by_split[entry.split] = by_split.get(entry.split, 0) + 1

    lines: list[str] = []
    lines.append(f"Total clips: {len(entries_list)}")
    lines.append("Per-tier × source:")
    for tier in sorted(by_tier):
        per_source = ", ".join(
            f"{source}={count}" for source, count in sorted(by_tier[tier].items())
        )
        total = sum(by_tier[tier].values())
        lines.append(f"  {tier}: {total} clips ({per_source})")
    if by_split:
        split_summary = ", ".join(f"{split}={count}" for split, count in sorted(by_split.items()))
        lines.append(f"Splits: {split_summary}")
    return "\n".join(lines)


def _refuse_synthetic_in_eval_splits(entries: Iterable[ClipEntry]) -> None:
    """Pre-write guard: bail loudly on bad synthetic-source manifests."""
    for entry in entries:
        if entry.split == "train":
            continue
        source = entry.source.lower()
        if any(source.startswith(prefix) for prefix in SYNTHETIC_SOURCE_PREFIXES):
            raise ValueError(
                f"Clip {entry.id!r} has synthetic source {entry.source!r} but "
                f"split={entry.split!r}; the manifest validator (and design "
                f"plan §5 R8) forbid synthetic-source clips in eval splits. "
                f"Either move to split='train' or remove."
            )


def build_manifest(
    *,
    guitarset_root: Path | None = None,
    utaustin_root: Path | None = None,
    guitar_techs_root: Path | None = None,
    gaps_root: Path | None = None,
    splits: tuple[str, ...] | None = None,
    max_clips_per_tier: int | None = None,
    total_limit: int | None = None,
    validation_player: str = GUITARSET_VALIDATION_PLAYER,
) -> list[ClipEntry]:
    """Scan all configured roots and apply filters + limits.

    Sources whose root is ``None`` or doesn't exist are silently skipped.
    Optional ``splits`` restricts to the named splits (e.g.
    ``("validation",)`` for a smoke pre-flight). Limits are applied
    after the split filter, sorted by clip id for determinism.
    """
    entries: list[ClipEntry] = []
    if guitarset_root is not None:
        entries.extend(scan_guitarset(guitarset_root, validation_player=validation_player))
    if utaustin_root is not None:
        entries.extend(scan_utaustin(utaustin_root))
    if guitar_techs_root is not None:
        entries.extend(scan_guitar_techs(guitar_techs_root))
    if gaps_root is not None:
        entries.extend(scan_gaps(gaps_root))

    _refuse_synthetic_in_eval_splits(entries)

    if splits is not None:
        allowed = set(splits)
        entries = [entry for entry in entries if entry.split in allowed]

    return apply_limits(
        entries,
        max_clips_per_tier=max_clips_per_tier,
        total_limit=total_limit,
    )


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: ``tabvision-build-composite-manifest``."""
    parser = argparse.ArgumentParser(
        prog="build_composite_manifest",
        description=("Scan dataset roots on disk and emit a composite-eval TOML manifest."),
    )
    parser.add_argument(
        "--guitarset",
        type=Path,
        default=None,
        help="GuitarSet root directory (with annotation/ and audio_mono-mic/)",
    )
    parser.add_argument(
        "--utaustin",
        type=Path,
        default=None,
        help="UT-Austin tablature dataset root (with tablature_audio/ and tablature_labels/)",
    )
    parser.add_argument(
        "--guitar-techs",
        type=Path,
        default=None,
        help="Guitar-TECHS root directory",
    )
    parser.add_argument(
        "--gaps",
        type=Path,
        default=None,
        help="GAPS root directory (with musicxml/, midi/, syncpoints/, audio/, CSV)",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--max-clips-per-tier",
        type=int,
        default=None,
        help="cap clips per tier; useful for smoke runs",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="cap total clips after per-tier cap; useful for smoke runs",
    )
    parser.add_argument(
        "--guitarset-validation-player",
        default=GUITARSET_VALIDATION_PLAYER,
        help="GuitarSet player id whose tracks go into the validation split",
    )
    parser.add_argument(
        "--splits",
        default=None,
        help=(
            "comma-separated splits to include (e.g. 'validation' for a "
            "smoke pre-flight). Default: include all splits."
        ),
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        default=None,
        help=(
            "rewrite media/annotation paths that fall under this root as "
            "$TABVISION_DATA_ROOT/<rest> for portable checked-in manifests"
        ),
    )

    args = parser.parse_args(argv)

    if (
        args.guitarset is None
        and args.utaustin is None
        and args.guitar_techs is None
        and args.gaps is None
    ):
        parser.error("specify at least one of --guitarset, --utaustin, --guitar-techs, or --gaps")

    splits_filter: tuple[str, ...] | None = None
    if args.splits:
        splits_filter = tuple(s.strip() for s in args.splits.split(",") if s.strip())

    try:
        entries = build_manifest(
            guitarset_root=args.guitarset,
            utaustin_root=args.utaustin,
            guitar_techs_root=args.guitar_techs,
            gaps_root=args.gaps,
            splits=splits_filter,
            max_clips_per_tier=args.max_clips_per_tier,
            total_limit=args.limit,
            validation_player=args.guitarset_validation_player,
        )
    except ValueError as exc:
        print(f"error: {exc}", flush=True)
        return 2

    if not entries:
        print(
            "No clips discovered. Check --guitarset / --utaustin / --guitar-techs paths.",
            flush=True,
        )
        return 1

    header = (
        "Composite-eval manifest generated by "
        "tabvision/scripts/eval/build_composite_manifest.py."
        "\nRe-generate with the same args to refresh; this file is "
        "intended to be auto-managed."
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        render_toml(entries, header_comment=header, data_root=args.data_root),
        encoding="utf-8",
        newline="\n",
    )

    print(f"Wrote {len(entries)} clips to {args.output}", flush=True)
    print(summarise_coverage(entries), flush=True)

    validation: ManifestValidation = validate_manifest(args.output)
    fail_items = [item for item in validation.items if item.severity == "fail"]
    if fail_items:
        print(f"\nValidation FAILED with {len(fail_items)} issue(s):", flush=True)
        for item in fail_items:
            print(f"  [{item.code}] {item.message}", flush=True)
        return 2

    print("\nManifest validation passed.", flush=True)
    return 0


__all__ = [
    "ClipEntry",
    "GUITARSET_VALIDATION_PLAYER",
    "apply_limits",
    "build_manifest",
    "main",
    "render_toml",
    "scan_gaps",
    "scan_guitar_techs",
    "scan_guitarset",
    "scan_utaustin",
    "summarise_coverage",
]


if __name__ == "__main__":
    raise SystemExit(main())
